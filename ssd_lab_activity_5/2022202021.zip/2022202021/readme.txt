index.html & studentRecords are the html files
script.js is the javascript file for both the html
style.css contains styling for both the html.

